This is a trivial project used to do manual tests of the announcement email sending process.

It is not run automatically; it would be too hard to catch and verify email.
